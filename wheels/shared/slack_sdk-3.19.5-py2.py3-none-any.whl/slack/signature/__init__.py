from slack_sdk.signature import SignatureVerifier  # noqa

from slack import deprecation

deprecation.show_message(__name__, "slack_sdk.signature")
